Flutter Quiz Starter - README

What's included:
- A minimal Flutter app (single screen quiz) using local JSON questions.
- AdMob placeholder area in UI (you must add google_mobile_ads plugin & your Ad Unit IDs).
- Instructions below to build an APK locally.

How to build APK (on your machine):
1. Install Flutter SDK: https://flutter.dev/docs/get-started/install
2. Ensure Android SDK & platform-tools are installed & ANDROID_HOME/Path setup.
3. Copy this project to a folder on your machine.
4. From project root run:
   flutter pub get
   flutter build apk --release
5. After build, APK will be at: build/app/outputs/flutter-apk/app-release.apk

To integrate Firestore / remote questions later:
- Add firebase_core and cloud_firestore packages and replace local JSON loading
  with Firestore queries. I can provide that code when you want.

AdMob:
- Add google_mobile_ads package and replace the banner placeholder with BannerAd widget.
- Use test ad unit IDs first to avoid policy issues.

If you want, I can provide:
- Firestore integration version
- AdMob integration code
- A small web admin (React) to add questions to Firestore
