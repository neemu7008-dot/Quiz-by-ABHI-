import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

void main() {
  runApp(const QuizApp());
}

class QuizApp extends StatelessWidget {
  const QuizApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quiz Starter',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<dynamic> _questions = [];
  int _current = 0;
  int _score = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadQuestions();
  }

  Future<void> _loadQuestions() async {
    final data = await rootBundle.loadString('assets/questions.json');
    setState(() {
      _questions = json.decode(data);
      _loading = false;
    });
  }

  void _answer(int idx) {
    final correct = _questions[_current]['answer_index'];
    if (idx == correct) _score++;
    if (_current < _questions.length - 1) {
      setState(() => _current++);
    } else {
      _showResult();
    }
  }

  void _showResult() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Result'),
        content: Text('Your score: \$_score / \${_questions.length}'),
        actions: [
          TextButton(
            onPressed: () {
              setState(() {
                _current = 0;
                _score = 0;
              });
              Navigator.pop(context);
            },
            child: const Text('Play Again'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final q = _questions[_current];
    return Scaffold(
      appBar: AppBar(title: const Text('Quiz Starter')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Question ${_current + 1} of ${_questions.length}', style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 12),
            Text(q['question'], style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            ...List.generate(q['options'].length, (i) {
              return Padding(
                padding: const EdgeInsets.only(bottom:8.0),
                child: ElevatedButton(
                  onPressed: () => _answer(i),
                  child: Text(q['options'][i]),
                ),
              );
            }),
            const Spacer(),
            // Placeholder for AdMob banner: implement with google_mobile_ads plugin
            Container(
              height: 60,
              color: Colors.grey.shade200,
              alignment: Alignment.center,
              child: const Text('AdMob Banner Placeholder (use test ad unit IDs)'),
            ),
          ],
        ),
      ),
    );
  }
}
